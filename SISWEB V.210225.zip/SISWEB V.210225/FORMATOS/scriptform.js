const tableBody = document.getElementById('table-body');

for (let i = 1; i <= 38; i++) {
    const row = document.createElement('tr');
    row.innerHTML = `
                <td>${i}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            `;
    tableBody.appendChild(row);
}


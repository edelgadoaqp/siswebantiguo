<?php
$servidor = "localhost";
$usuario = "root";
$clave = ""; // Cambia si tienes contraseña
$base_datos = "siswebalfa"; // Reemplaza con el nombre de tu BD
$puerto = 3307; // Especificar el puerto de MySQL

// Crear conexión con puerto
$conn = new mysqli($servidor, $usuario, $clave, $base_datos, $puerto);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Configurar codificación UTF-8
$conn->set_charset("utf8");

?>

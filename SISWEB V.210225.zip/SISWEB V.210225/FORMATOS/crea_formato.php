<?php include '../AUTH/auth.php'; ?>
<!-- Conexión a la base de datos-->
<?php
    include 'conexion.php'; // Asegúrate de tener un archivo para conectar a la BD
    $query = "SELECT ruc, nomtrans FROM tbltransportistas ORDER BY nomtrans ASC";
    $result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procesar Información</title>
    <link rel="stylesheet" href="stylesform.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <h3>REGISTRO DE ENVÍO Y RECEPCIÓN DE MERCADERÍA A PROVINCIAS</h3>
    <div class="form-container">
        <fieldset>
            <legend>Datos del Reparto</legend>

            <label for="empresa">Empresa de Transporte:</label>
            <select id="empresa">
                <option value="">Seleccione...</option>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='{$row['ruc']}'>{$row['nomtrans']}</option>";
                }
                ?>
            </select>

            <label for="transportista">Nombre del Transportista:</label>
            <input type="text" id="transportista" placeholder="Ingrese nombre">

            <label for="auxiliar">Nombre Auxiliar de Reparto:</label>
            <input type="text" id="auxiliar" placeholder="Ingrese nombre">

            <label for="placa">N° Placa:</label>
            <input type="text" id="placa" placeholder="Ingrese placa">
        </fieldset>

        <fieldset>
            <label for="raw-data">Pegar información:</label>
            <textarea id="raw-data" rows="5" placeholder="Pega aquí la informació del sistema..."></textarea>

        </fieldset>
        <button id="process-data" class="generar_button">Procesar</button>
    </div>

    <script>
        const processButton = document.getElementById('process-data');

        processButton.addEventListener('click', () => {
            const rawData = document.getElementById('raw-data').value;
            const empresa = document.getElementById('empresa').value;
            const transportista = document.getElementById('transportista').value;
            const auxiliar = document.getElementById('auxiliar').value;
            const placa = document.getElementById('placa').value;

            // Validar que haya información antes de continuar
            if (!rawData.trim()) {
                alert('Por favor, pega la información antes de continuar.');
                return;
            }

            // Guardar datos en localStorage
            localStorage.setItem('rawData', rawData);
            localStorage.setItem('empresa', empresa);
            localStorage.setItem('transportista', transportista);
            localStorage.setItem('auxiliar', auxiliar);
            localStorage.setItem('placa', placa);

            // Redirigir a formato.html
            window.location.href = 'formato.html';
        });
    </script>

    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
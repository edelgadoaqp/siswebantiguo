<?php
session_start(); // Verificar si la sesión está iniciada 
if (!isset($_SESSION['nombre']) || !isset($_SESSION['apellido'])) {
    header('Location: ../LOGIN/login.html');
    exit();
}
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];
$opcionesAcceso = explode(',', $_SESSION['opciones_acceso']);
$rol = $_SESSION['rol']; // Asumiendo que el rol está almacenado en la sesión ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de envio y recepcion de mercarderia a provincias</title>
    <link rel="stylesheet" href="stylesform.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <button class="back-button"
        onclick="window.location.href='<?php echo ($rol == 'admin') ? '../DASHBOARD/dashboard_admin.php' : '../DASHBOARD/dashboard_usuario.php'; ?>'">Regresar</button>
    <h3>INGRESAR DATOS</h3>

    <textarea id="inputData" rows="10" cols="50">
    </textarea>

    <button class="generar_button" id="generarButton">Generar formato</button>
    <script src="scriptform.js"></script>


    <?php include '../HEADERFOOTER/footer.php'; ?>

</body>

</html>
<?php
session_start(); // Verificar si la sesión está iniciada 
if (!isset($_SESSION['nombre']) || !isset($_SESSION['apellido'])) {
    header('Location: ../LOGIN/login.html');
    exit();
}
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];
$opcionesAcceso = explode(',', $_SESSION['opciones_acceso']);
$rol = $_SESSION['rol']; // Asumiendo que el rol está almacenado en la sesión
?>
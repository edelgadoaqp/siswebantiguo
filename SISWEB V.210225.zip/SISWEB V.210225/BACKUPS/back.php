<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD con HTML, CSS y JavaScript</title>
    <link rel="stylesheet" href="styles_back.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <h3>Gestión de Equipos</h3>
    <table id="data-table">
        <thead>
            <tr>
                <th>NOM DEL EQUIPO</th>
                <th>USUARIO</th>
                <th>DIA</th>
                <th>HORA</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!-- Aquí se insertarán las filas de datos -->
        </tbody>
    </table>
    <button onclick="addRow()">Añadir Fila</button>

    <script src="script_back.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
document.addEventListener('DOMContentLoaded', () => {
    fetch('back.txt')
        .then(response => response.text())
        .then(data => {
            const rows = data.trim().split('\n').slice(1); // Ignorar la primera línea (encabezados)
            const tableBody = document.querySelector('#data-table tbody');
            rows.forEach(row => {
                const columns = row.split('\t');
                const tr = document.createElement('tr');
                columns.forEach(column => {
                    const td = document.createElement('td');
                    td.textContent = column;
                    tr.appendChild(td);
                });
                const actionsTd = document.createElement('td');
                actionsTd.innerHTML = '<button onclick="editRow(this)">Editar</button> <button onclick="deleteRow(this)">Eliminar</button>';
                tr.appendChild(actionsTd);
                tableBody.appendChild(tr);
            });
        });
});

function addRow() {
    const tableBody = document.querySelector('#data-table tbody');
    const tr = document.createElement('tr');
    for (let i = 0; i < 4; i++) {
        const td = document.createElement('td');
        td.contentEditable = true;
        tr.appendChild(td);
    }
    const actionsTd = document.createElement('td');
    actionsTd.innerHTML = '<button onclick="saveRow(this)">Guardar</button> <button onclick="deleteRow(this)">Eliminar</button>';
    tr.appendChild(actionsTd);
    tableBody.appendChild(tr);
}

function editRow(button) {
    const tr = button.parentElement.parentElement;
    for (let i = 0; i < 4; i++) {
        tr.children[i].contentEditable = true;
    }
    button.textContent = 'Guardar';
    button.onclick = () => saveRow(button);
}

function saveRow(button) {
    const tr = button.parentElement.parentElement;
    for (let i = 0; i < 4; i++) {
        tr.children[i].contentEditable = false;
    }
    button.textContent = 'Editar';
    button.onclick = () => editRow(button);
    updateTxtFile();
}

function deleteRow(button) {
    const tr = button.parentElement.parentElement;
    tr.remove();
    updateTxtFile();
}

function updateTxtFile() {
    const rows = [];
    const tableBody = document.querySelector('#data-table tbody');
    tableBody.querySelectorAll('tr').forEach(tr => {
        const columns = [];
        for (let i = 0; i < 4; i++) {
            columns.push(tr.children[i].textContent);
        }
        rows.push(columns.join('\t'));
    });
    const data = 'NOM DEL EQUIPO\tUSUARIO\tDIA\tHORA\n' + rows.join('\n');
    fetch('update.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'data=' + encodeURIComponent(data),
    });
}

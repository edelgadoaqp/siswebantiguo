<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comparativo de Guias y FT</title>
    <link rel="stylesheet" href="styles_gft.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <h3>COMPARATIVO DE GUIAS Y FT</h3>
    <div class="input-group">
        <label for="guias">GUIAS SUITE: <span id="countGuias" class="count">0</span></label>
        <textarea id="guiasList" rows="10" placeholder="Ingrese el listado de Guias Electronicas"
            oninput="contarGuias()"></textarea>
    </div>

    <div class="input-group">
        <label for="facturas">FACTURAS SUITE: <span id="countFacturas" class="count">0</span></label>
        <textarea id="facturasList" rows="10" placeholder="Ingrese el listado de Facturas"
            oninput="contarFacturas()"></textarea>
    </div>

    <button onclick="verificarNumerosFaltantes()">Verificar</button>

    <div id="messages" class="floating-messages">
        <p id="resultadoGuias" class="resultado"></p>
        <p id="resultadoFacturas" class="resultado"></p>
        <p id="warning" class="warning"></p>
    </div>

    <?php include '../HEADERFOOTER/footer.php'; ?>
    <script src="script_gft.js"></script>
</body>

</html>
function contarGuias() {
    const guiasInput = document.getElementById('guiasList').value;
    const guiasCount = guiasInput.split('\n').filter(line => line.trim() !== '').length;
    document.getElementById('countGuias').innerText = guiasCount;
    return guiasCount; // Retornar el valor contado
}

function contarFacturas() {
    const facturasInput = document.getElementById('facturasList').value;
    const facturasCount = facturasInput.split('\n').filter(line => line.trim() !== '').length;
    document.getElementById('countFacturas').innerText = facturasCount;
    return facturasCount; // Retornar el valor contado
}

function verificarNumerosFaltantes() {
    const guiasInput = document.getElementById('guiasList').value.trim();
    const facturasInput = document.getElementById('facturasList').value.trim();
    const warningMessage = document.getElementById('warning');

    // Validación de entrada vacía
    if (!guiasInput || !facturasInput) {
        warningMessage.innerText = "Ambos campos deben estar completos.";
        return;
    } else {
        warningMessage.innerText = "";
    }

    const guiasNumeros = guiasInput.split('\n').map(Number).filter(n => !isNaN(n)).sort((a, b) => a - b);
    const facturasNumeros = facturasInput.split('\n').map(Number).filter(n => !isNaN(n)).sort((a, b) => a - b);

    const guiasFaltantes = encontrarNumerosFaltantes(guiasNumeros);
    const facturasFaltantes = encontrarNumerosFaltantes(facturasNumeros);

    document.getElementById('resultadoGuias').innerText = 
        guiasFaltantes.length > 0 ? 
        `GUIAS FALTANTES: ${guiasFaltantes.join(', ')}` : 
        'NO FALTAN GUIAS.';

    document.getElementById('resultadoFacturas').innerText = 
        facturasFaltantes.length > 0 ? 
        `FACTURAS FALTANTES: ${facturasFaltantes.join(', ')}` : 
        'NO FALTAN FACTURAS.';

    const guiasCount = contarGuias();
    const facturasCount = contarFacturas();

    if (guiasCount !== facturasCount) {
        warningMessage.innerText = 'REVISAR EN SISTEMA, LAS CANTIDADES DE GUIAS Y FACTURAS NO COINCIDEN';
    }
}

function encontrarNumerosFaltantes(numeros) {
    if (numeros.length === 0) return [];
    
    const primerNumero = numeros[0];
    const ultimoNumero = numeros[numeros.length - 1];
    const numerosFaltantes = [];

    for (let i = primerNumero; i <= ultimoNumero; i++) {
        if (!numeros.includes(i)) {
            numerosFaltantes.push(i);
        }
    }

    return numerosFaltantes;
}

<?php include '../AUTH/auth.php'; ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Lapso de Tiempo</title>
    <link rel="stylesheet" href="styles_calc.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <h3>Calculadora de Lapso de Tiempo</h3>
    <div>
        <label for="hora1">Primera Hora:</label>
        <input type="number" id="hora1" placeholder="HH" min="0" max="23">
        <input type="number" id="minuto1" placeholder="MM" min="0" max="59">
    </div>
    <div>
        <label for="hora2">Segunda Hora:</label>
        <input type="number" id="hora2" placeholder="HH" min="0" max="23">
        <input type="number" id="minuto2" placeholder="MM" min="0" max="59">
    </div>
    <button class="cal_tiempo_button" onclick="calcularLapso()">Calcular Lapso de Tiempo</button>
    <div>
        <h2>Lapso de Tiempo: <span id="resultado">0:00:00</span></h2>
    </div>
    <script src="script_calc.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
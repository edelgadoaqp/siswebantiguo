function calcularLapso() {
    const hora1 = parseInt(document.getElementById('hora1').value);
    const minuto1 = parseInt(document.getElementById('minuto1').value);
    const hora2 = parseInt(document.getElementById('hora2').value);
    const minuto2 = parseInt(document.getElementById('minuto2').value);

    const tiempo1 = new Date(0, 0, 0, hora1, minuto1, 0);
    const tiempo2 = new Date(0, 0, 0, hora2, minuto2, 0);

    let diferencia = tiempo2 - tiempo1;
    if (diferencia < 0) {
        diferencia += 24 * 60 * 60 * 1000; // Añadir 24 horas si la diferencia es negativa
    }

    const horas = Math.floor(diferencia / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
    const segundos = Math.floor((diferencia % (1000 * 60)) / 1000);

    document.getElementById('resultado').textContent = `${horas}:${minutos}:${segundos}`;
}

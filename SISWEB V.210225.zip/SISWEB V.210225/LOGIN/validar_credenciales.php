<?php
session_start(); // Iniciar la sesión

// Conexión a la base de datos
$conn = new mysqli('localhost', 'root', '', 'siswebalfa', 3307);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);
$usuario = $data['usuario'];
$contraseña = $data['contraseña'];

// Preparar la consulta SQL
$stmt = $conn->prepare("SELECT * FROM tblusuarios WHERE DNI = ? AND CodigoAlfa = ?");
$stmt->bind_param("ss", $usuario, $contraseña);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $rol = $row['Rol'];
    $nombre = $row['Nombres'];
    $apellido = $row['ApellidoPat'];
    $opcionesAcceso = $row['OpcionesAcceso'];

    // Establecer variables de sesión
    $_SESSION['nombre'] = $nombre;
    $_SESSION['apellido'] = $apellido;
    $_SESSION['rol'] = $rol;
    $_SESSION['opciones_acceso'] = $opcionesAcceso;

    // Redirigir según el rol
    if ($rol == 'admin') {
        $redirectUrl = '../dashboard/dashboard_admin.php';
    } else {
        $redirectUrl = '../dashboard/dashboard_usuario.php';
    }

    echo json_encode(['success' => true, 'redirectUrl' => $redirectUrl, 'nombre' => $nombre, 'apellido' => $apellido]);
} else {
    echo json_encode(['success' => false, 'message' => 'Credenciales incorrectas.']);
}

$stmt->close();
$conn->close();
?>

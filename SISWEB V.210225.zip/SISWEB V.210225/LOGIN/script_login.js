document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault(); // Evita que el formulario se envíe de forma predeterminada

        const usuario = document.getElementById("username").value;
        const contraseña = document.getElementById("password").value;
        const loader = document.getElementById("loader");

        // Muestra el loader
        loader.style.display = "flex";

        fetch('validar_credenciales.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ usuario, contraseña })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                setTimeout(() => {
                    window.location.href = data.redirectUrl; // Redirige después de 1.5s para ver el efecto
                }, 1500);
            } else {
                alert("Credenciales incorrectas. Inténtalo nuevamente.");
                loader.style.display = "none"; // Oculta el loader si hay error
            }
        })
        .catch(error => {
            console.error('Error:', error);
            loader.style.display = "none"; // Oculta el loader en caso de fallo
        });
    });
});

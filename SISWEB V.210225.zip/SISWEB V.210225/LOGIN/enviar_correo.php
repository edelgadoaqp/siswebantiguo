<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $ip = $_SERVER['REMOTE_ADDR'];

    // Aquí puedes validar el correo y realizar otras verificaciones necesarias

    $subject = 'Recuperación de contraseña';
    $message = "Este es un mensaje de recuperación de contraseña.\n\nIP del solicitante: $ip";

    // Envía el correo
    if (mail($email, $subject, $message)) {
        echo 'Correo enviado correctamente.';
    } else {
        echo 'Error al enviar el correo. Por favor, inténtalo nuevamente.';
    }
}
?>

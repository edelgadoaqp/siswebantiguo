<?php
session_start();
// Verificar si la sesión está iniciada y si el usuario tiene el rol de administrador 
if (!isset($_SESSION['nombre']) || !isset($_SESSION['apellido']) || $_SESSION['rol'] !== 'admin') {
    // Redirigir al usuario a la página de inicio de sesión si no está autenticado o no es administrador 
    header('Location: ../LOGIN/login.html');
    exit();
}

$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];

// Mensajes de depuración
error_log("Nombre: " . $nombre);
error_log("Apellido: " . $apellido);
error_log("Rol: " . $_SESSION['rol']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="styles2.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include '../HEADERFOOTER/header.php'; ?>
        <div class="menu">
            <div class="menu-item">
                <a href="../GUIASFTELECTRONICAS/ftguias.php">
                    <div class="icon">📄</div>
                    <div class="title">Guias y Facturas</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../FORMATOS/crea_formato.php">
                    <div class="icon">📑</div>
                    <div class="title">Formatos</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../LABORATORIOS/laboratorios.php">
                    <div class="icon">🧪</div>
                    <div class="title">Laboratorios</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../ETIQUETAS/generar_eti.php">
                    <div class="icon"><i class="fas fa-barcode"></i></div>
                    <div class="title">Generar Etiquetas</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../BACKUPS/back.php">
                    <div class="icon">💾</div>
                    <div class="title">Backups</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../CALCTIME/calculadora.php">
                    <div class="icon">⏱️</div>
                    <div class="title">Calc Tiempo</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../CREACION_GUIAS/crea_guia.php">
                    <div class="icon">🔄</div>
                    <div class="title">Guias Devolución</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../TRANSPORTE/transportista.php">
                    <div class="icon">🚛</div>
                    <div class="title">Transportista</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../GESTION/usuario.php">
                    <div class="icon">👥</div>
                    <div class="title">Usuarios</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../GUIASTRASLADO/form_guia_traslado.php">
                    <div class="icon">🚚</div>
                    <div class="title">Guias Traslado</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../GUIASMANUALES/guias_manuales.php">
                    <div class="icon">📋</div>
                    <div class="title">Guias Manuales</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="page3.html">
                    <div class="icon">⚠️</div>
                    <div class="title">Errores</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="page2.html">
                    <div class="icon">📚</div>
                    <div class="title">Manuales de Usuarios</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="../ACCESOS/acceso_user.php">
                    <div class="icon">👨‍💻</div>
                    <div class="title">Accesos a usuarios</div>
                </a>
            </div>
            <div class="menu-item">
                <a href="page2.html">
                    <div class="icon">⚙️</div>
                    <div class="title">Ajustes</div>
                </a>
            </div>
        </div>
        <?php include '../HEADERFOOTER/footer.php'; ?>
    </div>
</body>
</html>

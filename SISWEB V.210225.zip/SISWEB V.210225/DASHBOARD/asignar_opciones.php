<?php
// Conexión a la base de datos
$conn = new mysqli('localhost', 'root', '', 'siswebalfa', 3307);

$usuario = $_POST['usuario'];
$opciones = implode(',', $_POST['opciones']);

// Actualizar opciones de acceso del usuario
$sql = "UPDATE tblusuarios SET OpcionesAcceso = '$opciones' WHERE DNI = '$usuario'";
$conn->query($sql);

$conn->close();

header('Location: dashboard_admin.php');
?>

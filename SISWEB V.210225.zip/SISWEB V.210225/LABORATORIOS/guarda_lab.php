<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siswebalfa";
$port = 3307;

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener y validar datos
$numruc = filter_var($_POST['numruc'], FILTER_SANITIZE_STRING);
$nomcIi = filter_var($_POST['nomcIi'], FILTER_SANITIZE_STRING);
$codlab = filter_var($_POST['codlab'], FILTER_SANITIZE_STRING);
$dircli = filter_var($_POST['dircli'], FILTER_SANITIZE_STRING);
$NomDist = filter_var($_POST['NomDist'], FILTER_SANITIZE_STRING);
$NomProv = filter_var($_POST['NomProv'], FILTER_SANITIZE_STRING);
$NomDepa = filter_var($_POST['NomDepa'], FILTER_SANITIZE_STRING);

// Insertar datos
$sql = "INSERT INTO laboratorios (numruc, nomcIi, codlab, dircli, NomDist, NomProv, NomDepa) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $numruc, $nomcIi, $codlab, $dircli, $NomDist, $NomProv, $NomDepa);

if ($stmt->execute()) {
    echo "Nuevo laboratorio creado exitosamente";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siswebalfa";
$port = 3307;

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Preparar y ejecutar consulta
$sql = "SELECT codlab, nomcIi FROM laboratorios ORDER BY codlab";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['codlab']) . "</td>
                <td>" . htmlspecialchars($row['nomcIi']) . "</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='2'>No se encontraron resultados</td></tr>";
}

$stmt->close();
$conn->close();
?>

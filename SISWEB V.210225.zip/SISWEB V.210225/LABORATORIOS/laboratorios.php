<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratorios</title>
    <link rel="stylesheet" href="styles_lab.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>

    <h3>Lista de Laboratorios</h3>

    <div class="top-bar">
        <button onclick="window.location.href='crea_lab.html'" class="add-lab-btn">+ Agregar Nuevo Laboratorio</button>
        <div class="search-box">
            <input type="text" id="search" placeholder="Buscar...">
        </div>
    </div>

    <table id="laboratoriosTable">
        <thead>
            <tr>
                <th>COD LAB</th>
                <th>LABORATORIO</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'fetch_data.php'; ?>
        </tbody>
    </table>

    <script src="script_lab.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
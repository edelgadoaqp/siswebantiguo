document.addEventListener("DOMContentLoaded", function () {
    const loader = document.getElementById("loader");

    // Captura todos los enlaces para mostrar el loader al hacer clic
    document.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", function (event) {
            if (!link.href.includes("#") && !link.href.startsWith("javascript")) {
                event.preventDefault(); // Evita la redirección inmediata
                loader.style.display = "flex"; // Muestra el loader

                // Espera un momento antes de redirigir
                setTimeout(() => {
                    window.location.href = link.href;
                }, 900); // Ajusta el tiempo si es necesario
            }
        });
    });
});

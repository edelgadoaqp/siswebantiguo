<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido']; ?>

<head>
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
    <link rel="stylesheet" href="../HEADERFOOTER/loader.css">
</head>

<header>
    <img src="../IMAGES/logoalfaro.png" alt="Logo del Sistema" class="logo">
    <h1>Sistema Utilitarios</h1>

    <div class="user-menu">
        <button class="menu-btn" onclick="toggleMenu()">&#9776;</button>
        <div class="menu-content" id="userDropdown">
            <p><?php echo $nombre . ' ' . $apellido; ?></p>
            <a href="../USER/settings.php">Ajustes</a>
            <a href="../HEADERFOOTER/logout.php">Cerrar Sesión</a>
        </div>
    </div>
</header>

<!-- Loader de carga -->
<div id="loader" class="loader-container">
    <div class="loader"></div>
</div>

<script src="../HEADERFOOTER/loader.js"></script>
<script src="../HEADERFOOTER/menu.js"></script>
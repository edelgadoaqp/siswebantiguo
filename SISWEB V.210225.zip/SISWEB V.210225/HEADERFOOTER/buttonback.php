<button class="back-button"
    onclick="window.location.href='<?php echo ($rol == 'admin') ? '../DASHBOARD/dashboard_admin.php' : '../DASHBOARD/dashboard_usuario.php'; ?>'">↩️Regresar</button>

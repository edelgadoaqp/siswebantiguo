<footer>
    <p>© 2024 - 2025 Sistema Utilitarios by Erick. Todos los derechos reservados.</p>
</footer>

<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="acceso_user.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>

    <div class="asignar-opciones">
        <h2>Asignar Opciones de Acceso</h2>
        <form action="../DASHBOARD/asignar_opciones.php" method="post">
            <label for="usuario">Usuario (DNI):</label>
            <input type="text" id="usuario" name="usuario" required>

            <label for="opciones">Opciones:</label>
            <select id="opciones" name="opciones[]" multiple>
                <option value="guias_facturas">Guias y Facturas</option>
                <option value="formatos">Formatos</option>
                <option value="laboratorios">Laboratorios</option>
                <option value="generar_etiquetas">Generar Etiquetas</option>
                <option value="backups">Backups</option>
                <option value="calc_tiempo">Calc Tiempo</option>
                <option value="guias_devolucion">Guias Devolución</option>
                <option value="transportista">Transportista</option>
                <option value="usuarios">Usuarios</option>
                <option value="guias_traslado">Guias Traslado</option>
                <option value="errores">Errores</option>
                <option value="manuales_usuarios">Manuales de Usuarios</option>
                <option value="ajustes">Ajustes</option>
            </select>

            <button type="submit">Asignar</button>
        </form>
    </div>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
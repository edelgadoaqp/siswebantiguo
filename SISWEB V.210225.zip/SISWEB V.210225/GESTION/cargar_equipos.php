<?php
$conn = new mysqli('localhost', 'root', '', 'siswebalfa', 3307);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT IdEquipo, NombreEquipo FROM tblequipos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<option value='" . $row['IdEquipo'] . "'>" . $row['NombreEquipo'] . "</option>";
    }
} else {
    echo "<option value=''>No hay equipos disponibles</option>";
}
$conn->close();
?>

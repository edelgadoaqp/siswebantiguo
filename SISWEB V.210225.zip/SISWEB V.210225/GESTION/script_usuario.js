document.getElementById('search').addEventListener('keyup', function () {
    const searchValue = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#usuariosTable tbody tr');
    let hasResults = false;

    rows.forEach(function (row) {
        const cells = row.querySelectorAll('td');
        const rowText = Array.from(cells).map(cell => cell.textContent.toLowerCase()).join(' ');
        const match = rowText.includes(searchValue);

        row.style.display = match ? '' : 'none';
        if (match) hasResults = true;
    });

    // Mostrar mensaje si no hay resultados
    if (!hasResults) {
        const noResultsMessage = document.createElement('tr');
        noResultsMessage.id = 'noResultsMessage';
        noResultsMessage.innerHTML = '<td colspan="10">No hay resultados</td>';
        document.querySelector('#usuariosTable tbody').appendChild(noResultsMessage);
    } else {
        const noResultsMessage = document.getElementById('noResultsMessage');
        if (noResultsMessage) {
            noResultsMessage.remove();
        }
    }
});

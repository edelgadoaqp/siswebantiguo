<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="styles_usuario.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <button class="back-button" onclick="window.location.href='usuario.php'">Regresar</button>

    <h1>Gestión de Usuarios</h1>
    <form action="procesar_usuario.php" method="post">
        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" required>

        <label for="codigo_alfa">Código Alfa:</label>
        <input type="text" id="codigo_alfa" name="codigo_alfa">

        <label for="nombres">Nombres:</label>
        <input type="text" id="nombres" name="nombres" required>

        <label for="apellido_pat">Apellido Paterno:</label>
        <input type="text" id="apellido_pat" name="apellido_pat" required>

        <label for="apellido_mat">Apellido Materno:</label>
        <input type="text" id="apellido_mat" name="apellido_mat" required>

        <label for="area">Área:</label>
        <select id="area" name="area">
            <?php include 'cargar_areas.php'; ?>
        </select>

        <label for="cargo">Cargo:</label>
        <select id="cargo" name="cargo">
            <?php include 'cargar_cargos.php'; ?>
        </select>

        <label for="equipo">Equipo:</label>
        <select id="equipo" name="equipo">
            <?php include 'cargar_equipos.php'; ?>
        </select>

        <label for="estado">Estado:</label>
        <select id="estado" name="estado" required>
            <option value="Vigente">Vigente</option>
            <option value="Anulado">Anulado</option>
        </select>

        <input type="submit" value="Guardar Usuario">
    </form>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
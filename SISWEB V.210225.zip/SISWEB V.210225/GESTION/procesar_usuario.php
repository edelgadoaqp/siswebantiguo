<?php
$servername = "localhost"; // Cambiado a 127.0.0.1
$username = "root";
$password = "";
$dbname = "siswebalfa";
$port = 3307;

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$dni = $_POST['dni'];
$codigo_alfa = $_POST['codigo_alfa'];
$nombres = $_POST['nombres'];
$apellido_pat = $_POST['apellido_pat'];
$apellido_mat = $_POST['apellido_mat'];
$area = $_POST['area'];
$cargo = $_POST['cargo'];
$equipo = $_POST['equipo'];
$estado = $_POST['estado'];

// Insertar datos en la tabla
$sql = "INSERT INTO tblUsuarios (DNI, CodigoAlfa, Nombres, ApellidoPat, ApellidoMat, IdArea, IdCargo, IdEquipo, Estado)
VALUES ('$dni', '$codigo_alfa', '$nombres', '$apellido_pat', '$apellido_mat', '$area', '$cargo', '$equipo', '$estado')";

if ($conn->query($sql) === TRUE) {
    echo "<div id='message' class='message'>Nuevo usuario creado exitosamente</div>";
    echo "<script>
            setTimeout(function() {
                document.getElementById('message').style.display = 'none';
            }, 3000);
          </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

<style>
.message {
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #4CAF50;
    color: white;
    padding: 15px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
</style>

<?php
$conn = new mysqli('localhost', 'root', '', 'siswebalfa', 3307);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT IdArea, NombreArea FROM tblarea";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<option value='" . $row['IdArea'] . "'>" . $row['NombreArea'] . "</option>";
    }
} else {
    echo "<option value=''>No hay áreas disponibles</option>";
}
$conn->close();
?>

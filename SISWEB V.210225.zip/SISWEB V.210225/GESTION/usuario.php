<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="styles_usuario.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <h1>Gestión de Usuarios</h1>

    <div class="search-box">
        <input type="text" id="search" placeholder="Buscar por nombre o código">
    </div>

    </DIV>
    <div class="table-container">
        <table id="usuariosTable" border="1">
            <thead>
                <tr>
                    <th>DNI</th>
                    <th>CodigoAlfa</th>
                    <th>Nombres</th>
                    <th>ApellidoPat</th>
                    <th>ApellidoMat</th>
                    <th>IdCargo</th>
                    <th>IdEquipo</th>
                    <th>Estado</th>
                    <th>IdArea</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Conexión a la base de datos
                $conn = new mysqli('localhost', 'root', '', 'siswebalfa', 3307);
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                // Consulta para obtener los usuarios
                $sql = "SELECT * FROM tblusuarios ORDER BY CodigoAlfa";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['DNI']}</td>
                                <td>{$row['CodigoAlfa']}</td>
                                <td>{$row['Nombres']}</td>
                                <td>{$row['ApellidoPat']}</td>
                                <td>{$row['ApellidoMat']}</td>
                                <td>{$row['IdCargo']}</td>
                                <td>{$row['IdEquipo']}</td>
                                <td>{$row['Estado']}</td>
                                <td>{$row['IdArea']}</td>
                                <td>
                                    <a href='edit.php?DNI={$row['DNI']}'>Editar</a>
                                    <a href='delete.php?DNI={$row['DNI']}'>Eliminar</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='10'>No hay usuarios</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <button type="button" class="add-user-btn" onclick="window.location.href='nuevo_usuario.php'">Agregar nuevo
        usuario</button>

    <!-- Incluir el archivo JavaScript -->
    <script src="script_usuario.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
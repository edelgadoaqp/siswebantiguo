//SELECCIONADA LA FECHA DE HOY
document.addEventListener('DOMContentLoaded', (event) => {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('fecha_emision').value = today;
});

///////////////////////////////

// Buscar datos del cliente por RUC
// Agregar un listener para buscar datos del cliente al presionar Enter
document.getElementById('ruc').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevenir el envío del formulario por defecto
        buscarCliente();
    }
});

// Buscar datos del cliente por RUC
function buscarCliente() {
    var ruc = document.getElementById('ruc').value.trim();
    if (ruc !== '') {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (Object.keys(data).length > 0) {
                        document.getElementById('nombre_razon_social').value = data.nomcIi || '';
                        document.getElementById('direccion').value = data.dircli || '';
                        document.getElementById('domicilio_llegada').value = data.dircli || '';
                        document.getElementById('localidad').value =
                            (data.NomDist || '') + ' - ' +
                            (data.NomProv || '') + ' - ' +
                            (data.NomDepa || '');
                    } else {
                        alert('No se encontraron datos para el RUC ingresado.');
                    }
                } else {
                    console.error('Error al obtener los datos del cliente. Código de estado:', xhr.status);
                }
            }
        };
        xhr.open('GET', '../CREACION_GUIAS/buscar_cliente.php?ruc=' + ruc, true);
        xhr.send();
    } else {
        alert('Por favor, ingresa un RUC válido.');
    }
}

// Agregar un listener para buscar datos del transportista al presionar Enter
document.getElementById('ruc_trans').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevenir el envío del formulario por defecto
        buscarTrans();
    }
});

// Buscar datos del Transportista por RUC
function buscarTrans() {
    var ruc = document.getElementById('ruc_trans').value.trim();
    if (ruc !== '') {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (Object.keys(data).length > 0) {
                        document.getElementById('nombre_trans').value = data.Nomtrans || '';
                    } else {
                        alert('No se encontraron datos para el RUC ingresado.');
                    }
                } else {
                    console.error('Error al obtener los datos del transportista. Código de estado:', xhr.status);
                }
            }
        };
        xhr.open('GET', '../CREACION_GUIAS/buscar_trans.php?ruc=' + ruc, true);
        xhr.send();
    } else {
        alert('Por favor, ingresa un RUC válido.');
    }
}

//CREACION DEL FORMATO IMPRIMIBLE
function crearGuia() {
    const data = {
        fecha_emision: document.getElementById('fecha_emision').value,
        ruc: document.getElementById('ruc').value,
        localidad: document.getElementById('localidad').value,
        nombre_razon_social: document.getElementById('nombre_razon_social').value,
        domicilio_partida: document.getElementById('domicilio_partida').value,
        direccion: document.getElementById('direccion').value,
        domicilio_llegada: document.getElementById('domicilio_llegada').value,
        descripcion: document.getElementById('textarea').value
    };

    localStorage.setItem('guiaData', JSON.stringify(data));
    window.location.href = '../GUIASMANUALES/printable.html';
}

document.querySelector('input[value="Crear Guía"]').addEventListener('click', crearGuia);

// Limpiar campos del formulario
function limpiarCampos() {
    document.getElementById('dataForm').reset();
}

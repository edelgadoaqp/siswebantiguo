<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de etiquetas</title>
    <link rel="stylesheet" href="styles_eti.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>

    <h3>Generar Etiqueta</h3>
    <textarea id="inputData" rows="10" cols="50">
    </textarea>
    <br><br>
    <label for="labelCount">Cantidad de etiquetas por hoja:</label>
    <select id="labelCount">
        <option value="3">3</option>
        <option value="2">2</option>
        <option value="1">1</option>
    </select>
    <br><br>
    <button class="generar_button" onclick="generateTable()">Crear etiqueta</button>

    <script>
        function generateTable() {
            const inputData = document.getElementById('inputData').value;
            const labelCount = document.getElementById('labelCount').value;
            const rows = inputData.trim().split('\n').slice(1);
            let tableHTML = '';
            let tableCount = 0;
            let fontSize = 48;

            if (labelCount == 2) {
                fontSize = 60;
            } else if (labelCount == 1) {
                fontSize = 80;
            }

            rows.forEach(row => {
                const columns = row.split('\t');
                tableHTML += `<table><tr><th>CODIGO</th><td>${columns[0]}</td></tr>`;
                tableHTML += `<tr><td colspan="2">${columns[1]}</td></tr>`;
                tableHTML += `<tr><th>FECHA VTO</th><th>LOTE</th></tr>`;
                tableHTML += `<tr><td>${columns[3]}</td><td>${columns[2]}</td></tr></table><br>`;
                tableCount++;

                if (tableCount % labelCount === 0) {
                    tableHTML += '<div class="page-break"></div>';
                }
            });

            const newWindow = window.open();
            newWindow.document.write(`<html><head><title>Tabla Generada</title><style>
                table { width: 100%; border-collapse: collapse; page-break-inside: avoid; }
                table, th, td { border: 3px solid black; }
                th, td { padding: 8px; text-align: left; font-size: ${fontSize}px; font-family: Arial, sans-serif; }
                th { font-weight: bold; }
                @media print { body { width: 210mm; height: 297mm; }
                .page-break { page-break-after: always; } }
            </style></head><body>`);
            newWindow.document.write(tableHTML);
            newWindow.document.write('</body></html>');
            newWindow.document.close();
        }
    </script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
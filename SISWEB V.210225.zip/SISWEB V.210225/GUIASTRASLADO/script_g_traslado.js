function crearGuia() {
    const cantBultos = document.getElementById('cantBultos').value;
    const razonSocial = document.getElementById('razonSocial').value;
    const direccion = document.getElementById('direccion').value;
    const localidad = document.getElementById('localidad').value;
    const guiaTraslado = document.getElementById('guiaTraslado').value;
    const guiasRemision = document.getElementById('guiasRemision').value;
    const cantDoc = document.getElementById('cantDoc').value;
    const motivoTraslado = document.getElementById('motivoTraslado').value;

    let newWindow = window.open('', '', 'width=800,height=600');
    newWindow.moveTo(0, 0);
    newWindow.resizeTo(screen.width, screen.height);
    newWindow.document.write('<html><head><title>Guías de Traslado</title>');
    newWindow.document.write('<link rel="stylesheet" href="styles_g_traslado.css">');
    newWindow.document.write('<style>@page { size: 210mm 297mm; margin: 50mm 10mm 5mm 10mm; } .guia { page-break-after: always; } table { width: 100%; height: 60%; } th, td { font-size: 18px; padding: 5px; border: 2px solid black; }</style></head><body>');

    for (let i = 0; i < cantBultos; i++) {
        newWindow.document.write(`
            
            <br><div class="guia">
                <table>
                    
                    <tr>
                        <th colspan="3">RAZON SOCIAL:</th>
                    </tr>
                    <tr>
                        <td colspan="3">${razonSocial}</td>
                    </tr>
                    <tr>
                        <td colspan="3" class="no-border"></td>
                    </tr>
                    <tr>
                        <th colspan="3">DIRECCIÓN</th>
                    </tr>
                    <tr>
                        <td colspan="3">${direccion}</td>
                    </tr>
                    <tr>
                        <td colspan="3" class="no-border"></td>
                    </tr>
                    <tr>
                        <th colspan="3">LOCALIDAD</th>
                    </tr>
                    <tr>
                        <td colspan="3">${localidad}</td>
                    </tr>
                    <tr>
                        <th>N°- GUIA DE REMISION</th>
                        <th>CANT. DE BULTOS</th>
                        <th>CANT DE DOC.</th>
                    </tr>
                    <tr>
                        <td>${guiasRemision}</td>
                        <td>${i + 1} DE ${cantBultos}</td>
                        <td>${cantDoc}</td>
                    </tr>
                    <tr>
                        <th>GUIA DE TRASLADO</th>
                        <th colspan="2">MOTIVO DEL TRASLADO</th>
                    </tr>
                    <tr>
                        <td>${guiaTraslado}</td>
                        <td colspan="2">${motivoTraslado}</td>
                    </tr>
                </table>
            </div><BR><BR><BR><BR>
                    `);
        if ((i + 1) % 2 === 0) {
            newWindow.document.write('<div style="page-break-after: always;"></div>');
        }
    }

    newWindow.document.write('</body></html>');
    newWindow.document.close();
}

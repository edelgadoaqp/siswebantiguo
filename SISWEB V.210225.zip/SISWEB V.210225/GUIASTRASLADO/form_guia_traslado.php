<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles_g_traslado.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
    <title>Formulario de Guías</title>
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <div class="container">
        <h2>ROTULOS DE TRASLADO A LIMA</h2>
        <form id="guiaForm">

            <div class="form-group">
                <label for="razonSocial">Razón Social:</label>
                <input type="text" id="razonSocial" name="razonSocial" required>
            </div>
            <div class="form-group">
                <label for="direccion">Dirección:</label>
                <input type="text" id="direccion" name="direccion" required>
            </div>
            <div class="form-group">
                <label for="localidad">Localidad:</label>
                <input type="text" id="localidad" name="localidad" required>
            </div>
            <div class="form-group">
                <label for="guiaTraslado">Guía de traslado:</label>
                <input type="text" id="guiaTraslado" name="guiaTraslado" required>
            </div>
            <div class="form-group">
                <label for="guiasRemision">Guías Remisión:</label>
                <input type="text" id="guiasRemision" name="guiasRemision" required>
            </div>
            <div class="form-group">
                <label for="cantBultos">Cant. bultos:</label>
                <input type="number" id="cantBultos" name="cantBultos" required>
            </div>
            <div class="form-group">
                <label for="cantDoc">Cant. docs:</label>
                <input type="number" id="cantDoc" name="cantDoc" required>
            </div>
            <div class="form-group">
                <label for="motivoTraslado">Motivo de traslado:</label>
                <input type="text" id="motivoTraslado" name="motivoTraslado" required>
            </div>
            <button type="button" onclick="crearGuia()">Crear Guia</button>
        </form>
        <div id="output"></div>
    </div>
    <script src="script_g_traslado.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Transportista</title>
    <link rel="stylesheet" href="styles_trans.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <button class="back-button" onclick="window.location.href='../TRANSPORTE/transportista.php'">Regresar</button>
    <div class="form-container">
        <h3>Crear Transportista</h3>
        <form action="guarda_trans.php" method="post">
            <div class="form-group">
                <label for="numruc">RUC:</label>
                <input type="text" id="numruc" name="numruc" required>
            </div>
            <div class="form-group">
                <label for="nomtrans">Nombre Transportista:</label>
                <input type="text" id="nomtrans" name="nomtrans" required>
            </div>
            <button type="submit" class="btn-save">Guardar</button>
        </form>
    </div>


    <script src="script_trans.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
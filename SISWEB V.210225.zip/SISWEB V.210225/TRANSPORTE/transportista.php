<?php include '../AUTH/auth.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratorios</title>
    <link rel="stylesheet" href="styles_trans.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <?php include '../HEADERFOOTER/buttonback.php'; ?>
    <h3>Lista de Transportistas</h3>

    <div class="top-bar">
        <button onclick="window.location.href='crea_trans.php'" class="add-lab-btn">Agregar Nuevo</button>
        <div class="search-box">
            <input type="text" id="search" placeholder="Buscar...">
        </div>
    </div>

    <table id="transportistasTable">
        <thead>
            <tr>
                <th>RUC</th>
                <th>NOMBRE TRANSPORTISTA</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'fetch_data.php'; ?>
        </tbody>
    </table>

    <script src="script_trans.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
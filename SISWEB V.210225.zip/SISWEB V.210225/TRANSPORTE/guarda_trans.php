<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siswebalfa";
$port = 3307;

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener y validar datos
$numruc = filter_var($_POST['numruc'], FILTER_SANITIZE_STRING);
$nomtrans = filter_var($_POST['nomtrans'], FILTER_SANITIZE_STRING);

// Insertar datos
$sql = "INSERT INTO tbltransportistas (ruc, nomtrans) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $numruc, $nomtrans);

if ($stmt->execute()) {
    echo "Nuevo laboratorio creado exitosamente";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>

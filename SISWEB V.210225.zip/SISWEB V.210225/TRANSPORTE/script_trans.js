document.getElementById('search').addEventListener('keyup', function () {
    const searchValue = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#transportistasTable tbody tr');
    let hasResults = false;

    rows.forEach(function (row) {
        const cells = row.querySelectorAll('td');
        const rowText = Array.from(cells).map(cell => cell.textContent.toLowerCase()).join(' ');
        const match = rowText.includes(searchValue);

        row.style.display = match ? '' : 'none';
        if (match) hasResults = true;
    });

    document.getElementById('noResultsMessage').style.display = hasResults ? 'none' : 'block';
});

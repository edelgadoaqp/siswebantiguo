<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file']['tmp_name'];
    $handle = fopen($file, "r");

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "siswebalfa";
    $port = 3307;

    if ($handle) {
        $conn = new mysqli($servername, $username, $password, $dbname, $port);

        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        while (($line = fgets($handle)) !== false) {
            $data = explode("\t", trim($line)); // Asumiendo que los datos están separados por tabulaciones
            $codigo = $data[0];
            $descripcion = $data[1];
            $und = $data[2];
            $lote = $data[3];
            $f_venc = $data[4];
            $stock = $data[5];
            $area = $data[6];
            $codlab = $data[7];

            // Convertir la fecha de DD/MM/YYYY a YYYY-MM-DD
            $f_venc = date("Y-m-d", strtotime(str_replace('/', '-', $f_venc)));

            $sql = "INSERT INTO tblproducto (codprod, descripcion, und, lote, f_venc, stock, area, codlab) VALUES ('$codigo', '$descripcion', '$und', '$lote', '$f_venc', '$stock', '$area', '$codlab')";

            if (!$conn->query($sql)) {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        fclose($handle);
        $conn->close();
        echo "Archivo cargado y productos insertados correctamente.";
    } else {
        echo "Error al abrir el archivo.";
    }
} else {
    echo "No se ha seleccionado ningún archivo.";
}
?>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 21-02-2025 a las 20:47:24
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `siswebalfa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `laboratorios`
--

CREATE TABLE `laboratorios` (
  `numruc` varchar(20) NOT NULL,
  `nomcIi` varchar(255) NOT NULL,
  `codlab` varchar(50) NOT NULL,
  `dircli` varchar(255) DEFAULT NULL,
  `NomDist` varchar(100) DEFAULT NULL,
  `NomProv` varchar(100) DEFAULT NULL,
  `NomDepa` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `laboratorios`
--

INSERT INTO `laboratorios` (`numruc`, `nomcIi`, `codlab`, `dircli`, `NomDist`, `NomProv`, `NomDepa`) VALUES
('20100018625', 'MEDIFARMA S.A.', '05', 'JR. ECUADOR NRO. 787', 'LIMA', 'LIMA', 'LIMA'),
('20100060150', 'HERSIL S.A.', '08', 'AV. LOS FRUTALES 220 URB. FDO MONTERRICO GRANDE', 'ATE', 'LIMA', 'LIMA'),
('20100061717', 'LABORATORIOS TRIFARMA S.A.', '09', 'AV. SANTA ROSA 390 URB. AURORA', 'ATE', 'LIMA', 'LIMA'),
('20100091543', 'GRUNENTHAL PERUANA S A', '10', 'CALLE  DE LAS LETRAS 261', 'SAN BORJA', 'LIMA', 'LIMA'),
('20100096855', 'SANOFI-AVENTIS DEL PERÚ S.A.', '66', 'AV. JAVIER PRADO ESTE 444 OF. 1501 SAN ISIDRO', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20100099447', 'MERCK  PERUANA S.A.', '15', 'AV. LOS FRUTALES NRO. 220 URB. MONTERRICO OESTE A', 'ATE', 'LIMA', 'LIMA'),
('20100123682', 'GLAXOSMITHKLINE PERU S.A.', '03', 'AV. VICTOR ANDRES BELAUNDE NRO.147 INT.07', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20100127165', 'PROCTER & GAMBLE PERÚ S.R.L.', '86', 'AV. JUAN DE ARONA 151 OFICINA 302', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20100127670', 'PFIZER S.A.', '02', 'CAL.LAS ORQUIDEAS NRO. 585 INT. 701 URB. JARDIN', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20100134617', 'MEGA LABS LATAM S.A.', '49', 'JR. FAUSTINO SNACHEZ CARRION Nº 425 URB. SAN FELIPE', 'MAGDALENA DEL MAR', 'LIMA', 'LIMA'),
('20100152941', 'KIMBERLY CLARK PERÚ S.R.L.', '37', 'AV. PASEO DE LA REPUBLICA N°5895 INT 301', 'MIRAFLORES', 'LIMA', 'LIMA'),
('20100284937', 'EUROFARMA PERU S.A.C.', '18', 'AV. BOLIVIA N°1161 URB. CHACRA COLORADA', 'BREÑA', 'LIMA', 'LIMA'),
('20100287791', 'INSTITUTO QUIMIOTERÁPICO S.A.', '40', 'AV. SANTA ROSA N°350 URB. VILLA SANTA ANITA', 'SANTA ANITA', 'LIMA', 'LIMA'),
('20100309191', 'OM PHARMA S.A.', '04', 'JR. RICARDO REY BASADRE 385 RES. MAGDALENA DEL MAR', 'MAGDALENA DEL MAR', 'LIMA', 'LIMA'),
('20101129153', 'LABORATORIOS ELIFARMA S.A.', '20', 'AV. SEPARADORA INDUSTRIAL N°1823 URB. EL ARTESANO', 'ATE', 'LIMA', 'LIMA'),
('20101260373', 'TECNOFARMA S.A.', '36', 'AV. JAVIER PRADO ESTE Nº456 PISO 18 INT. 1801-1802', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20101269834', 'TEVA PERU S.A.', '84', 'AV. LA MOLINA 135', 'ATE', 'LIMA', 'LIMA'),
('20137530911', 'APOYO A PROGRAMAS DE POBLACIÓN', '59', 'AV. CANAVAL Y MOREYRA 345 INT PSO3', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20260344341', 'MERCK SHARP & DOHME PERU S.R.L.', '63', 'AV. CIRCUNVALACIÓN  NRO. 134 URB. CLUB GOLF LOS INCAS', 'SANTIAGO DE SURCO', 'LIMA', 'LIMA'),
('20347268683', 'LABORATORIOS AC FARMA S.A.', '43', 'CAL. LOS HORNOS Nº110 URB. INDUSTRIAL VULCANO', 'ATE', 'LIMA', 'LIMA'),
('20476798770', 'CAFERMA S.A.C.', '82', 'CAL. VIRREY MANUEL AMAT Nº202 URB. LA COLONIAL', 'CALLAO', 'CALLAO', 'CALLAO'),
('20507249214', 'GENOMMA LAB PERÚ S.A.', '94', 'AV. VICTOR ANDRES BELAUNDE NRO.147 INT. 504', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20509629111', 'DISTRIMED S.A.C.', '11', 'AV. JORGE CHAVEZ NRO. 154 INT. 401 URB. JOSE BALTA', 'MIRAFLORES', 'LIMA', 'LIMA'),
('20523163320', 'BOEHRINGER INGELHEIM PERU S.A.', '87', 'AV. CANAVAL Y MOREYRA N°480 PISO 20 URB LIMA TAMBO', 'SAN ISIDRO', 'LIMA', 'LIMA'),
('20523951603', 'LABORATORIOS SIEGFRIED S.A.C.', '81', 'AV. JORGE CHAVEZ 263 PISO 7 URB SURQUILLO', 'MIRAFLORES', 'LIMA', 'LIMA'),
('20543309959', 'QM PHARMA QUALITY MEDICINE S.A.C.', '91', 'AV. TOMAS RAMSEY N° 930 INT. 811 URB. SAN FELIPE', 'MAGDALENA DEL MAR', 'LIMA', 'LIMA'),
('20548138648', 'GALENICUM VITAE PERU S.A.C.', '74', 'AV. DEL PINAR 110 OF. 405 URB. CHACARILLA DEL ESTANQUE', 'SANTIAGO DE SURCO', 'LIMA', 'LIMA'),
('20604423555', 'SANULAC NUTRICION PERU S.A.C.', '48', 'AV JORGE CHAVEZ N°275 INT. 502', 'MIRAFLORES', 'LIMA', 'LIMA'),
('20607649937', 'HALEON PERÚ S.R.L.', '30', 'AV. JORGE BASADRE 347 PISO 5 OFC. 05W-109', 'SAN ISIDRO', 'LIMA', 'LIMA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblarea`
--

CREATE TABLE `tblarea` (
  `IdArea` int(11) NOT NULL,
  `NombreArea` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblarea`
--

INSERT INTO `tblarea` (`IdArea`, `NombreArea`) VALUES
(1, 'ADMINISTRATIVA'),
(2, 'MANTENIMIENTO'),
(3, 'SISTEMAS'),
(4, 'TELEMARKETING'),
(5, 'ALMACÉN'),
(6, 'CONTABLE'),
(7, 'ASEGURAMIENTO'),
(8, 'TRANSPORTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblcargos`
--

CREATE TABLE `tblcargos` (
  `IdCargo` int(11) NOT NULL,
  `NombreCargo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblcargos`
--

INSERT INTO `tblcargos` (`IdCargo`, `NombreCargo`) VALUES
(1, 'ADMINISTRADORA'),
(2, 'DIRECTOR TECNICO'),
(3, 'AUX. DE MANTENIMIENTO'),
(4, 'AUX. DE SISTEMAS'),
(5, 'AUX. DE TELEMARKETING'),
(6, 'INGRESOS'),
(7, 'AUX. DE COSTOS'),
(8, 'SUP. DE ALMACÉN'),
(9, 'ENC. DE PISO'),
(10, 'AYU. DE ALMACÉN'),
(11, 'MOTORIZADO'),
(12, 'ENC. DE INGRESOS'),
(13, 'FACTURACIÓN'),
(14, 'ASISTENTE DE DT'),
(15, 'EMBALAJES'),
(16, 'ALMACEN'),
(17, 'ASEGURAMIENTO'),
(18, 'ASIST. MANTENIMIENTO'),
(19, 'RECEPCIONISTA'),
(20, 'CHOFER'),
(21, 'ENC. DESPACHO'),
(22, 'ENC. DE CONTROLADOS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblequipos`
--

CREATE TABLE `tblequipos` (
  `IdEquipo` int(11) NOT NULL,
  `NombreEquipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblequipos`
--

INSERT INTO `tblequipos` (`IdEquipo`, `NombreEquipo`) VALUES
(1, 'Sin Equipo'),
(2, 'ALFAQP010'),
(3, 'ALFAQP011'),
(4, 'ALFAQP012'),
(5, 'ALFAQP013'),
(6, 'ALFAQP014'),
(7, 'ALFAQP015'),
(8, 'ALFAQP016'),
(9, 'ALFAQP017'),
(10, 'ALFAQP018'),
(11, 'ALFAQP019'),
(12, 'ALFAQP020'),
(13, 'ALFAQP021'),
(14, 'ALFAQP022'),
(15, 'ALFAQP023'),
(16, 'ALFAQP024'),
(17, 'ALFAQP025'),
(18, 'ALFAQP026'),
(19, 'ALFAQP027');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbltransportistas`
--

CREATE TABLE `tbltransportistas` (
  `ruc` varchar(11) NOT NULL,
  `nomtrans` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbltransportistas`
--

INSERT INTO `tbltransportistas` (`ruc`, `nomtrans`) VALUES
('20100227461', 'TRANSPORTES CRUZ DEL SUR S.A.C.'),
('20100812623', 'MOT DISTRIBUIDORES S.A.'),
('20101420320', 'JET CARGO SERVICE S.A.C.'),
('20102295961', 'TRADEL SERVICE S.R.L.'),
('20252501178', 'CORPORACION DE SERVICIOS GENERALES G&R S.A.'),
('20349728185', 'BUSINEES SERVICE CARGO S.A.'),
('20392676083', 'TRASPORTES LD ROJAS E.I.R.L.'),
('20478057246', 'ALEIZAI CARGO S.A.C.'),
('20501471934', 'TRANSPORTES GENERALES JORV S.A.C.'),
('20503693586', 'WARI EXPRESS S.A.C.'),
('20504078885', 'TRASPORTE & LOGISTICA TRANSVIAS'),
('20509670260', 'TRASPORTES MONTANO E.I.R.L'),
('20517448371', 'WORLD CARRIER EXPRESS S.A.C.'),
('20522120902', 'ROSYMAR PERU S.A.C.'),
('20525087469', 'FENIX LOGISTIC S.A.C.'),
('20536452592', 'LAGVIRUR S.A.C.'),
('20538843939', 'LOG S.A.C.'),
('20547881851', 'TRANSVIAS LOGISTICA S.A.C.'),
('20549754491', 'CORPORACION DE TRANSPORTES HUAYRAS PERU S.A.C.'),
('20557950371', 'MED LOGISTIC S.A.C.'),
('20601248728', 'GRUPO SPC PERU S.A.C.'),
('20601470561', 'TRANSPORTE MIGRIVAL');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblusuarios`
--

CREATE TABLE `tblusuarios` (
  `IdUsuario` int(11) NOT NULL,
  `DNI` varchar(20) NOT NULL,
  `CodigoAlfa` varchar(50) DEFAULT NULL,
  `Nombres` varchar(100) NOT NULL,
  `ApellidoPat` varchar(100) NOT NULL,
  `ApellidoMat` varchar(100) NOT NULL,
  `IdArea` int(11) NOT NULL,
  `IdCargo` int(11) NOT NULL,
  `IdEquipo` int(11) NOT NULL,
  `Estado` enum('Activo','Inactivo') NOT NULL,
  `Rol` enum('admin','usuario') NOT NULL DEFAULT 'usuario',
  `OpcionesAcceso` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tblusuarios`
--

INSERT INTO `tblusuarios` (`IdUsuario`, `DNI`, `CodigoAlfa`, `Nombres`, `ApellidoPat`, `ApellidoMat`, `IdArea`, `IdCargo`, `IdEquipo`, `Estado`, `Rol`, `OpcionesAcceso`) VALUES
(1, '47219330', 'AQ004', 'Erick José', 'Delgado', 'Arratea', 3, 4, 5, '', 'admin', NULL),
(2, '41804320', 'AQ016', 'Edwin', 'Tapia', 'Cachique', 5, 8, 10, '', 'usuario', 'formatos');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `laboratorios`
--
ALTER TABLE `laboratorios`
  ADD PRIMARY KEY (`numruc`);

--
-- Indices de la tabla `tblarea`
--
ALTER TABLE `tblarea`
  ADD PRIMARY KEY (`IdArea`);

--
-- Indices de la tabla `tblcargos`
--
ALTER TABLE `tblcargos`
  ADD PRIMARY KEY (`IdCargo`);

--
-- Indices de la tabla `tblequipos`
--
ALTER TABLE `tblequipos`
  ADD PRIMARY KEY (`IdEquipo`);

--
-- Indices de la tabla `tbltransportistas`
--
ALTER TABLE `tbltransportistas`
  ADD PRIMARY KEY (`ruc`);

--
-- Indices de la tabla `tblusuarios`
--
ALTER TABLE `tblusuarios`
  ADD PRIMARY KEY (`IdUsuario`),
  ADD UNIQUE KEY `DNI` (`DNI`),
  ADD KEY `IdArea` (`IdArea`),
  ADD KEY `IdCargo` (`IdCargo`),
  ADD KEY `IdEquipo` (`IdEquipo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tblarea`
--
ALTER TABLE `tblarea`
  MODIFY `IdArea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tblcargos`
--
ALTER TABLE `tblcargos`
  MODIFY `IdCargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `tblequipos`
--
ALTER TABLE `tblequipos`
  MODIFY `IdEquipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `tblusuarios`
--
ALTER TABLE `tblusuarios`
  MODIFY `IdUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tblusuarios`
--
ALTER TABLE `tblusuarios`
  ADD CONSTRAINT `tblusuarios_ibfk_1` FOREIGN KEY (`IdArea`) REFERENCES `tblarea` (`IdArea`),
  ADD CONSTRAINT `tblusuarios_ibfk_2` FOREIGN KEY (`IdCargo`) REFERENCES `tblcargos` (`IdCargo`),
  ADD CONSTRAINT `tblusuarios_ibfk_3` FOREIGN KEY (`IdEquipo`) REFERENCES `tblequipos` (`IdEquipo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

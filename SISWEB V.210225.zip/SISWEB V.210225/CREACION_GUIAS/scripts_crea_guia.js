//SELECCIONADA LA FECHA DE HOY
document.addEventListener('DOMContentLoaded', (event) => {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('fecha_emision').value = today;
});
///////////////////////////////

// Buscar datos del cliente por RUC
// Agregar un listener para buscar datos del cliente al presionar Enter
document.getElementById('ruc').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevenir el envío del formulario por defecto
        buscarCliente();
    }
});

// Buscar datos del cliente por RUC
function buscarCliente() {
    var ruc = document.getElementById('ruc').value.trim();
    if (ruc !== '') {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (Object.keys(data).length > 0) {
                        document.getElementById('nombre_razon_social').value = data.nomcIi || '';
                        document.getElementById('direccion').value = data.dircli || '';
                        document.getElementById('domicilio_llegada').value = data.dircli || '';
                        document.getElementById('localidad').value =
                            (data.NomDist || '') + ' - ' +
                            (data.NomProv || '') + ' - ' +
                            (data.NomDepa || '');
                    } else {
                        alert('No se encontraron datos para el RUC ingresado.');
                    }
                } else {
                    console.error('Error al obtener los datos del cliente. Código de estado:', xhr.status);
                }
            }
        };
        xhr.open('GET', 'buscar_cliente.php?ruc=' + ruc, true);
        xhr.send();
    } else {
        alert('Por favor, ingresa un RUC válido.');
    }
}

// Agregar un listener para buscar datos del transportista al presionar Enter
document.getElementById('ruc_trans').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevenir el envío del formulario por defecto
        buscarTrans();
    }
});

// Buscar datos del Transportista por RUC
function buscarTrans() {
    var ruc = document.getElementById('ruc_trans').value.trim();
    if (ruc !== '') {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (Object.keys(data).length > 0) {
                        document.getElementById('nombre_trans').value = data.Nomtrans || '';
                    } else {
                        alert('No se encontraron datos para el RUC ingresado.');
                    }
                } else {
                    console.error('Error al obtener los datos del transportista. Código de estado:', xhr.status);
                }
            }
        };
        xhr.open('GET', 'buscar_trans.php?ruc=' + ruc, true);
        xhr.send();
    } else {
        alert('Por favor, ingresa un RUC válido.');
    }
}

// Buscar datos del producto por código
document.getElementById('codigo').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevenir el envío del formulario por defecto
        buscarProducto();
    }
});

document.getElementById('lote').addEventListener('change', function () {
    actualizarVencimiento();
});

function buscarProducto() {
    var codigo = document.getElementById('codigo').value.trim();
    if (codigo !== '') {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    if (Object.keys(data).length > 0) {
                        document.getElementById('descripcion').value = data.descripcion || '';
                        var loteSelect = document.getElementById('lote');
                        loteSelect.innerHTML = ''; // Limpiar opciones anteriores
                        data.lotes.forEach(function (lote) {
                            var option = document.createElement('option');
                            option.value = lote.lote;
                            option.text = lote.lote;
                            option.dataset.vencimiento = lote.f_venc;
                            loteSelect.appendChild(option);
                        });
                        actualizarVencimiento();
                    } else {
                        alert('No se encontraron datos para el código ingresado.');
                    }
                } else {
                    console.error('Error al obtener los datos del producto. Código de estado:', xhr.status);
                }
            }
        };
        xhr.open('GET', 'buscar_producto.php?codigo=' + codigo, true);
        xhr.send();
    } else {
        alert('Por favor, ingresa un código válido.');
    }
}

function actualizarVencimiento() {
    var loteSelect = document.getElementById('lote');
    var selectedOption = loteSelect.options[loteSelect.selectedIndex];
    var vencimiento = selectedOption ? selectedOption.dataset.vencimiento : '';
    document.getElementById('vcmto').value = vencimiento;
}


//AGREGAR PRODUCTO AL LISTADO
const productos = []; // Array para almacenar los productos

function agregarProducto() {
    //const codigo = document.getElementById("codigo").value;
    const cantidad = document.getElementById("cantidad").value;
    const descripcion = document.getElementById("descripcion").value;
    const lote = document.getElementById("lote").value;
    const vencimiento = document.getElementById("vcmto").value;

    const nuevoProducto = {
        //codigo,
        cantidad,
        descripcion,
        lote,
        vencimiento
    };

    productos.push(nuevoProducto);
    actualizarTabla();

    // Limpiar los campos después de agregar el producto
    document.getElementById("codigo").value = '';
    document.getElementById("cantidad").value = '';
    document.getElementById("descripcion").value = '';
    document.getElementById("lote").value = '';
    document.getElementById("vcmto").value = '';
}

function actualizarTabla() {
    const tableBody = document.querySelector("#product-table tbody");
    tableBody.innerHTML = ''; // Limpiar la tabla antes de actualizar

    productos.forEach(producto => {
        const row = document.createElement("tr");

        Object.values(producto).forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        tableBody.appendChild(row);
    });
}

//CREACION DEL FORMATO IMPRIMIBLE
function crearGuia() {
    const data = {
        fecha_emision: document.getElementById('fecha_emision').value,
        ruc: document.getElementById('ruc').value,
        localidad: document.getElementById('localidad').value,
        nombre_razon_social: document.getElementById('nombre_razon_social').value,
        domicilio_partida: document.getElementById('domicilio_partida').value,
        direccion: document.getElementById('direccion').value,
        domicilio_llegada: document.getElementById('domicilio_llegada').value,
        productos: []
    };

    const rows = document.querySelectorAll('#product-table tbody tr');
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        data.productos.push({
            cantidad: cells[0].innerText,
            descripcion: cells[1].innerText,
            lote: cells[2].innerText,
            vencimiento: cells[3].innerText
        });
    });

    localStorage.setItem('guiaData', JSON.stringify(data));
    window.location.href = '../CREACION_GUIAS/printable.html';
}

document.querySelector('input[value="Crear Guía"]').addEventListener('click', crearGuia);


// Limpiar campos del formulario
function limpiarCampos() {
    document.getElementById('dataForm').reset();
}



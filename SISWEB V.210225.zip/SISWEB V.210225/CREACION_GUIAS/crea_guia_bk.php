<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Datos</title>
    <link rel="stylesheet" href="styles_crea_guia.css">
    <link rel="stylesheet" href="../HEADERFOOTER/styles_head_foot.css">
</head>

<body>
    <?php include '../HEADERFOOTER/header.php'; ?>
    <button class="back-button" onclick="window.location.href='../DASHBOARD/index2.php'">Regresar</button>

    <form id="dataForm" action="procesar.php" method="post">
        <h3>Creación de Guía de Devolución</h3>
        <!--COLUMNA IZQUIERDA-->
        <div class="left-column">
            <fieldset class="group">
                <legend>Datos del laboratorio</legend>
                <div class="form-group">
                    <label for="fecha_emision">Fecha de Emisión:</label>
                    <input type="date" id="fecha_emision" name="fecha_emision" required>
                </div>
                <div class="form-group">
                    <label for="ruc">RUC:</label>
                    <input type="text" id="ruc" name="ruc" required>
                </div>
                <div class="form-group">
                    <label for="nombre_razon_social">Nombre o Razón Social:</label>
                    <input type="text" id="nombre_razon_social" name="nombre_razon_social" required disabled>
                </div>
                <div class="form-group">
                    <label for="direccion">Dirección:</label>
                    <input type="text" id="direccion" name="direccion" required disabled>
                </div>
                <div class="form-group">
                    <label for="localidad">Localidad:</label>
                    <input type="text" id="localidad" name="localidad" required disabled>
                </div>
            </fieldset>
            <fieldset class="group">
                <legend>Direcciones</legend>
                <div class="form-group">
                    <label for="domicilio_partida">Domicilio de Partida:</label>
                    <select id="domicilio_partida" name="domicilio_partida" required>
                        <option value="seleccion" selected>Seleccionar un Domicilio de Partida</option>
                        <option value="Calle Miguel Grau">Calle Miguel Grau 624 - Miraflores - Arequipa</option>
                        <option value="Otro">Otro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="domicilio_llegada">Domicilio de Llegada:</label>
                    <input type="text" id="domicilio_llegada" name="domicilio_llegada" required disabled>
                </div>
            </fieldset>

            <fieldset class="group">
                <legend>Datos del transportista</legend>
                <div class="form-group">
                    <label for="ruc_tra">RUC Transportista:</label>
                    <input type="text" id="ruc_tra" name="ruc_tra" required>
                </div>
                <div class="form-group">
                    <label for="nombre_trans">Nombre o Razón Social:</label>
                    <input type="text" id="nombre_trans" name="nombre_trans" required disabled>
                </div>
            </fieldset>

        </div>

        <!--COLUMNA DERECHA-->
        <div class="right-column">
            <!--<h4>Búsqueda y Agregado de Productos</h4>-->
            <fieldset class="group">
                <legend>Búsqueda y Agregado de Productos</legend>
                <div class="form-group">
                    <label for="codigo">Código:</label>
                    <input type="text" id="codigo" required>
                </div>
                <div class="form-group">
                    <label for="cantidad">Cantidad:</label>
                    <input type="number" id="cantidad" required>
                </div>

                <div class="form-group">
                    <label for="descripcion">Descripción:</label>
                    <input type="text" id="descripcion" required disabled>
                </div>

                <!--<div class="form-group">
                <label for="lote">Lote:</label>
                <input type="text" id="lote" required>
            </div>-->
                <div class="form-group">
                    <label for="lote">Lote:</label>
                    <select id="lote" required></select>
                </div>

                <div class="form-group">
                    <label for="vcmto">Vencimiento:</label>
                    <input type="date" id="vcmto" required disabled>
                </div>
            </fieldset>
            <div class="button-group">
                <input type="button" value="Agregar" onclick="agregarProducto()"></input>
                <input type="button" value="Limpiar Campos" onclick="limpiarCampos()">
                <input type="button" value="Crear Guía" onclick="crearGuia()"></input>
            </div>
            <div class="form-group">
                <!-- Tabla para mostrar los productos -->
                <table id="product-table">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Cantidad</th>
                            <th>Descripción</th>
                            <th>Lote</th>
                            <th>Vencimiento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Aquí se agregarán las filas de productos -->
                    </tbody>
                </table>
            </div>
        </div>

        <div class="form-group button-group-full">


        </div>
    </form>
    <script src="scripts_crea_guia.js"></script>
    <?php include '../HEADERFOOTER/footer.php'; ?>
</body>

</html>
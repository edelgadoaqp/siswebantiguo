<?php
if (isset($_GET['codigo'])) {
    $codigo = $_GET['codigo'];

    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "siswebalfa";
    $port = 3307;

    // Crear conexión
    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "SELECT descripcion FROM tblproducto WHERE codprod = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $codigo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $descripcion = $row['descripcion'];

        $sql = "SELECT lote, f_venc FROM tblproducto WHERE codprod = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $codigo);
        $stmt->execute();
        $result = $stmt->get_result();

        $lotes = [];
        while ($row = $result->fetch_assoc()) {
            $lotes[] = $row;
        }

        echo json_encode(['descripcion' => $descripcion, 'lotes' => $lotes]);
    } else {
        echo json_encode([]);
    }

    $stmt->close();
    $conn->close();
}
?>

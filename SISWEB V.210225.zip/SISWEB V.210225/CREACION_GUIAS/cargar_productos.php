<?php
$servername = "localhost";  // Cambiar si es necesario
$username = "root";         // Cambiar si es necesario
$password = "";             // Cambiar si es necesario
$dbname = "bd_alfaqp"; // Cambiar si es necesario

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_FILES['archivo_txt']['error'] == UPLOAD_ERR_OK && is_uploaded_file($_FILES['archivo_txt']['tmp_name'])) {
    $archivo = fopen($_FILES['archivo_txt']['tmp_name'], 'r');
    
    while (($line = fgets($archivo)) !== false) {
        $data = explode("\t", trim($line));
        
        if (count($data) == 5) {
            $codigo = $conn->real_escape_string($data[0]);
            $descripcion = $conn->real_escape_string($data[1]);
            $und = $conn->real_escape_string($data[2]);
            $lote = $conn->real_escape_string($data[3]);

            // Convertir fecha de DD/MM/YYYY a YYYY-MM-DD
            $fecha = DateTime::createFromFormat('d/m/Y', $data[4]);
            if ($fecha) {
                $fecven = $fecha->format('Y-m-d');
            } else {
                echo "Error en el formato de fecha: " . $data[4] . "<br>";
                continue; // Saltar esta línea y continuar con la siguiente
            }
            
            $sql = "INSERT INTO productos (codigo, descripcion, und, lote, fecven) 
                    VALUES ('$codigo', '$descripcion', '$und', '$lote', '$fecven')";
            
            if (!$conn->query($sql)) {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Error en el formato de la línea: " . $line . "<br>";
        }
    }
    
    fclose($archivo);
    echo "Datos cargados exitosamente.";
} else {
    echo "Error al subir el archivo.";
}

$conn->close();
?>

<?php
// buscar_cliente.php
if (isset($_GET['ruc'])) {
    $ruc = $_GET['ruc'];

    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "siswebalfa";
    $port = 3307;

    // Crear conexión
    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "SELECT nomcIi, dircli, NomDist, NomProv, NomDepa FROM laboratorios WHERE numruc = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $ruc);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode([]);
    }

    $stmt->close();
    $conn->close();
}
?>